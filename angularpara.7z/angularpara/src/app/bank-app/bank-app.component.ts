import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bank-app',
  templateUrl: './bank-app.component.html',
  styleUrls: ['./bank-app.component.css']
})
export class BankAppComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
