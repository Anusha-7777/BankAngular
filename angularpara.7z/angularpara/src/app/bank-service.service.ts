import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from 'selenium-webdriver/http';
import { BankApp } from './bank-app';

@Injectable({
  providedIn: 'root'
})
export class BankServiceService {

  constructor(private httpClient:HttpClient) { }


  public createAccount(bankDetails) {
  return this.httpClient.post<BankApp>("http://localhost:8080/addAccount", bankDetails);
  
  /*showBalance(accountnum): Observable<number>
  {
  console.log(accountnum);
  return this.httpClient.get<number>("http://localhost:8080/bank/{accountnum}" + accountnum)
  } */
}
}
