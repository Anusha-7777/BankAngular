import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BankAppComponent } from './bank-app/bank-app.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { ShowBAlanceComponent } from './show-balance/show-balance.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { CashtransferComponent } from './cashtransfer/cashtransfer.component';
import { TransactionComponent } from './transaction/transaction.component';
import { SignupComponent } from './signup/signup.component';

@NgModule({
  declarations: [
    AppComponent,
    BankAppComponent,
    LoginPageComponent,
    CreateAccountComponent,
    ShowBAlanceComponent,
    DepositComponent,
    WithdrawComponent,
    CashtransferComponent,
    TransactionComponent,
    SignupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
