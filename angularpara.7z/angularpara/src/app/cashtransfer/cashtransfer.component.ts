import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cashtransfer',
  templateUrl: './cashtransfer.component.html',
  styleUrls: ['./cashtransfer.component.css']
})
export class CashtransferComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
