import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowBAlanceComponent } from './show-balance.component';

describe('ShowBAlanceComponent', () => {
  let component: ShowBAlanceComponent;
  let fixture: ComponentFixture<ShowBAlanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowBAlanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowBAlanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
