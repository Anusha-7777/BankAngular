export class BankApp {
    public accountId: number;
    public userName: string;
    public phoneNumber: number;
    public password: string;
  
    public balance: number;
}

	