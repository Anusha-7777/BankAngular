import { BankApp } from './bank-app';

describe('BankApp', () => {
  it('should create an instance', () => {
    expect(new BankApp()).toBeTruthy();
  });
});
